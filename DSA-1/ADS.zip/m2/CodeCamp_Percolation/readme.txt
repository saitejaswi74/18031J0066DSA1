Input:
First line of the input denotes size of the grid
from second line to last line of input denotes indexes of grid that are open

Output:
print true if grid can percolates else false

Note:
Indexe values of grid will be from 1 to N(size of grid) (both inclusive)