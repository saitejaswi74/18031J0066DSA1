input:
first line of input is int N represent no of elements in given array
Below N line represents each element in the array

output:
print 3-sum value of the array 